#include "mainheader.h"


int main() {
	int isGameOver = 0;

	// ���� ó��
	srand((unsigned)time(NULL));
	
	GameManager game;
	game.GameRun();


}