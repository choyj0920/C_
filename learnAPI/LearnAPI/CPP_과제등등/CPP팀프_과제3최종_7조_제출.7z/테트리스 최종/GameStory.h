#pragma once
class GameStory
{
public:
	GameStory();
	~GameStory();
	void gameOver();
	void gamePrologue();
	void oldman(int, int);
	void show_dialogue(int, int);
	void trans();
	void nextYear(int x, int y);
	void walk(int x, int y);
	void show_text(const char* str);
	void title(int, int);
	void show_ending();
	void show_getGetNextBlockStick();
	void show_getClearAllBlock();

};

