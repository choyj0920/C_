﻿#include "mainheader.h"
#include <queue>
#include <list>


int main() {
	int isGameOver = 0;

	// 난수 처리
	srand((unsigned)time(0));
	
	GameManager game;
	int x = 0, y = 0;
	GameStory story;
	
	game.GameRun();


}